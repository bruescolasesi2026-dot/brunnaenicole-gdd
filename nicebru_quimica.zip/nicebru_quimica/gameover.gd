extends Control

func _on_btn_jogar_pressed():
	# Carrega a primeira fase
	get_tree().change_scene_to_file("res://Level1.tscn")

func _on_btn_sair_pressed():
	# Fecha o jogo
	get_tree().quit()
