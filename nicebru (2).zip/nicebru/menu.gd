extends Control

# Referências aos botões dentro do VBoxContainer
# (ajuste os caminhos se "play", "controls" e "quit" estiverem
# dentro do HBoxContainer em vez de direto no VBoxContainer)
@onready var play_button: Button = $play
@onready var controls_button: Button = $controls
@onready var quit_button: Button = $quit


func _on_play_pressed() -> void:
	# Troque pelo caminho real da sua cena de jogo
	get_tree().change_scene_to_file("res://Level1.tscn")


func _on_controls_pressed() -> void:
	# Troque pelo caminho real da sua cena/tela de controles
	get_tree().change_scene_to_file("res://cenas/controles.tscn")


func _on_quit_pressed() -> void:
	get_tree().quit()
